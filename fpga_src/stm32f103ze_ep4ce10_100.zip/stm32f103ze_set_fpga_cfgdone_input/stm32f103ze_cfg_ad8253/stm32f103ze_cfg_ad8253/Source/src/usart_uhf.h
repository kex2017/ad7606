#ifndef   __USART_UHF_H__
#define   __USART_UHF_H__

#define ATMEGA_VER			0x01
#define OPER_READ			0x52
#define OPER_WRITE			0x57

#define SET_UHF_ENV			0x01
#define GET_UHF_ENV			0x10

#define HEAD_LEN			4

//enum SWITCH{OFF,ON};

typedef struct {
unsigned short freq;
unsigned char lock_freq_flag;
unsigned char filter_pre_gain;
unsigned char filter_VGA_gain;
unsigned char filter_cutoff_freq;
unsigned char chann1_sw;
unsigned char chann1_gain;
unsigned char chann2_sw;
unsigned char chann2_gain;
unsigned char local_osc_VGA;
unsigned char local_osc_filter;
}STRU_UHF_ENV,*PSTRU_UHF_ENV;


void init_uhf_usart3(void);
int set_uhf_board_env(unsigned short freq,unsigned char *plock_freq_flag,unsigned char filter_pre_gain,
					unsigned char filter_VGA_gain,unsigned char filter_cutoff_freq,unsigned char chann1_sw,
					unsigned char chann1_gain,unsigned char chann2_sw,unsigned char chann2_gain,
					unsigned char local_osc_VGA,unsigned char local_osc_filter);
					
void set_uhf_gain(unsigned char channel,unsigned short gain);
void set_uhf_fre(unsigned char channel,unsigned short fre,unsigned bandwidth);

#endif  /* __USART_WATCH_H__ */
