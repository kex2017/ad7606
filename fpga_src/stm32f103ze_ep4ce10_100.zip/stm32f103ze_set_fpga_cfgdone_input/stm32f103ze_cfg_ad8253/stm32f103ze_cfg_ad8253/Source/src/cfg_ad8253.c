#include "stm32f10x.h"
#include <stdio.h>
#include "cfg_ad8253.h"


//PE8 wr
//PE9 a1
//PE10 a0


//PG7 wr
//PG8 a1
//PC6 a0

//PG14 PG15

void init_cfg_pwr_io(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC
			| RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE| RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG,
				ENABLE);
	
	
	GPIO_SetBits(GPIOG,  GPIO_Pin_14 | GPIO_Pin_13);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	
	GPIO_WriteBit(GPIOG,  GPIO_Pin_14, (BitAction)0);//
	GPIO_WriteBit(GPIOG,  GPIO_Pin_13, (BitAction)0);//
}

void init_cfg_ad8253_io(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* ��1������GPIOA GPIOC GPIOD GPIOF GPIOG��ʱ��
	   ע�⣺����ط�����һ����ȫ��
	*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC
			| RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE| RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG,
				ENABLE);


	GPIO_SetBits(GPIOF,  GPIO_Pin_13);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
	
	
	
	
	GPIO_SetBits(GPIOA,  GPIO_Pin_8);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	GPIO_SetBits(GPIOG,  GPIO_Pin_7 | GPIO_Pin_8);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOC,  GPIO_Pin_6);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);


	GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)1);//
	GPIO_WriteBit(GPIOE,  GPIO_Pin_9, (BitAction)0);//
	GPIO_WriteBit(GPIOE,  GPIO_Pin_10, (BitAction)0);//

	GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)1);//
	GPIO_WriteBit(GPIOG,  GPIO_Pin_8, (BitAction)0);//
	GPIO_WriteBit(GPIOC,  GPIO_Pin_6, (BitAction)0);//
	
	
	GPIO_WriteBit(GPIOA,  GPIO_Pin_8, (BitAction)0);//
	init_cfg_pwr_io();
	
}

void cfg_ad8253(unsigned char gain)
{
	switch(gain)
	{
		case 0://gain=1
		{
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_9, (BitAction)0);//
			GPIO_WriteBit(GPIOE,  GPIO_Pin_10, (BitAction)0);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)0);//
			delay(1);
		}break;
		case 1://gain=10
		{
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_9, (BitAction)0);//
			GPIO_WriteBit(GPIOE,  GPIO_Pin_10, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)0);//
			delay(1);
		}break;
		case 2://gain=100
		{
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_9, (BitAction)1);//
			GPIO_WriteBit(GPIOE,  GPIO_Pin_10, (BitAction)0);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)0);//
			delay(1);
		}break;
		case 3://gain=1000
		{
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_9, (BitAction)1);//
			GPIO_WriteBit(GPIOE,  GPIO_Pin_10, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOE,  GPIO_Pin_8, (BitAction)0);//
			delay(1);
		}break;
	}
}

void cfg_ad8253_pflc_a(unsigned char gain)
{
	switch(gain)
	{
		case 0://gain=1
		{
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_8, (BitAction)0);//
			GPIO_WriteBit(GPIOC,  GPIO_Pin_6, (BitAction)0);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)0);//
			delay(1);
		}break;
		case 1://gain=10
		{
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_8, (BitAction)0);//
			GPIO_WriteBit(GPIOC,  GPIO_Pin_6, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)0);//
			delay(1);
		}break;
		case 2://gain=100
		{
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_8, (BitAction)1);//
			GPIO_WriteBit(GPIOC,  GPIO_Pin_6, (BitAction)0);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)0);//
			delay(1);
		}break;
		case 3://gain=1000
		{
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_8, (BitAction)1);//
			GPIO_WriteBit(GPIOC,  GPIO_Pin_6, (BitAction)1);//
			delay(1);
			GPIO_WriteBit(GPIOG,  GPIO_Pin_7, (BitAction)0);//
			delay(1);
		}break;
	}
}