


#include "stm32f10x.h"
#include "fpga_fsmc.h"

#include <math.h>
#include "usart_uhf.h"



#define DAT_LEN 804

unsigned char channel_display_select=5;

//#define FifoPointCheck

/*=============================================================================
  ϵͳȫ��ı���
  =============================================================================*/




//uint8_t fpga_FSMC_Init_Ok = 0;	/* ����ָʾFSMC�Ƿ��ʼ�� */



unsigned int cha2_read_dat_cnt_global=0;

void calc_abc(float *dest, signed short *src, uint32_t len,unsigned char channel)
{
    uint32_t i = 0;
		float max_current=0;
		float min_curretn=-100;
		short max_dat;
		short min_dat;
    signed short *p = (signed short *)src;
		unsigned char gain;
	
		if( (channel>=4)&&(channel<=6) )
		{
			gain = 6;
		}
		else if( (channel>=7)&&(channel<=9) )
		{
			gain = (6*16);
		}

		max_current=0;
		min_curretn=0;
		max_dat = 0 ;
		min_dat = 32767;
    for (i = 0; i < len / 2; i++) {
			
				if(max_dat<(*p))
				{
					max_dat = (*p);
				}
				if(min_dat>(*p))
				{
					min_dat = (*p);
				}
				
        *dest = ((float)(*p) * 2048) / (32768 * gain * 10);   //456Ϊ10 , 789Ϊ 1
				if(max_current<(*dest))
				{
					max_current = (*dest);
				}
				if(min_curretn > (*dest))
				{
					min_curretn = (*dest);
				}
        dest++;
        p++;
    }
		printf("max_current=%f min_curretn=%f max_dat=%d min_dat=%d len=%d\r\n",max_current,min_curretn,max_dat,min_dat,len/2);
}

void calc_pf_current_abc(float *value, float *data, uint32_t len)
{
    uint32_t i = 0;
    float tmp = 0;
    float sum = 0;

    for (i = 0; i < len / 2; i++) {
        tmp = *data;
        sum += (tmp * tmp);
				data++;
    }
    *value = (float)sqrt(sum/(len/2));
   
}

//run_chabit4~ bit13Ϊ1�ֱ�����ɼ�0~9·ͨ������ʼ�ɼ�
void start_run_old(unsigned short run_cha)
{
 	
   	fpga_write(0, run_cha);
}

//return 1 �Ѳɼ����   0:���ڲɼ�
unsigned short check_sample_dat_over_old(unsigned char channel)
{
   volatile unsigned short dat;


   fpga_write(0, channel);//ѡ���Ӧ��ͨ��
   dat = fpga_read(1);//��ȡ��Ӧͬʱ�Ƿ�ɼ����

   if (dat & (1 << 0)) {
      return 1;
   }
   else {
      return 0;
   }
}

unsigned int read_channel_dat_len_old(unsigned char channel)
{
   unsigned int dat_len;
   unsigned short tmp_h;
   unsigned short tmp_l;


 /*  fpga_write(0, channel);

   tmp_h = fpga_read(2);
   tmp_l = fpga_read(3);

   dat_len = (tmp_h << 16) + tmp_l;

   return (dat_len<<1);//���ص����ݳ�����u8�ĳ���*/
		if(channel<4)
		{
				//return 20000;
				return 600;
		}
		else 
		{
				return 20480;
		}
}

unsigned int read_channel_data_old(unsigned char channel, unsigned int dat_len, unsigned short *buf, unsigned char first)
{
	unsigned int i,n;
	volatile unsigned short *p;
	volatile unsigned short m;


	p = (volatile unsigned short *)buf;

	dat_len >>= 1;
	if(first)
	{
		fpga_write(0, (1<<14)|channel);
		m = fpga_read(7);
	}
	for(i=0;i<dat_len;i++)
	{
		*p = fpga_read(7);
	//	printf("%d,%d\n",i,*p);
		p++;
	}
}





/*******************************************************************************
*	������: FPGA_CtrlLinesConfig
*	��  ��: ��
*	��  ��: ��
*	��  ��: ����FPGA���ƿ��ߣ�FSMC�ܽ�����Ϊ���ù���
*/
static void FPGA_CtrlLinesConfig_old(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* ʹ�� FSMC, GPIOD, GPIOE, GPIOF, GPIOG �� AFIO ʱ�� */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE |
	                     RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG |
	                     RCC_APB2Periph_AFIO, ENABLE);

	/* ���� PD.00(D2), PD.01(D3), PD.04(NOE), PD.05(NWE), PD.08(D13), PD.09(D14),
	 PD.10(D15), PD.14(D0), PD.15(D1) Ϊ����������� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5 |
	                            GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_14 |
	                            GPIO_Pin_15; // | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	/* ���� PE.07(D4), PE.08(D5), PE.09(D6), PE.10(D7), PE.11(D8), PE.12(D9), PE.13(D10),
	 PE.14(D11), PE.15(D12) Ϊ����������� */
	/* PE3,PE4 ����A19, A20, STM32F103ZE-EK(REV 2.0)����ʹ�� */
	/* PE5,PE6 ����A21, A22, STM32F103ZE-EK(REV 1.0)����ʹ�� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
	                            GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 |
	                            GPIO_Pin_15 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	/* ���� PD11(A16)  PD12(A17)  PD13(A18))  Ϊ����������� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13;
	//GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_12;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	/* ���� PD.7(NE1 ) Ϊ�����������  */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}

/*******************************************************************************
*	������: FPGA_FSMCConfig
*	��  ��: ��
*	��  ��: ��
*	��  ��: ����FSMC���ڷ���ʱ��
*/
static void FPGA_FSMCConfig_old(void)
{
	FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
	FSMC_NORSRAMTimingInitTypeDef  FSMC_NORSRAMTimingInitStructure;

	/*-- FSMC Configuration ------------------------------------------------------*/
	/*----------------------- SRAM Bank 1 ----------------------------------------*/
	/* FSMC_Bank1_NORSRAM1 configuration */
	FSMC_NORSRAMTimingInitStructure.FSMC_AddressSetupTime = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_AddressHoldTime = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_DataSetupTime = 14;	   //xiewei
	FSMC_NORSRAMTimingInitStructure.FSMC_BusTurnAroundDuration = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_CLKDivision = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_DataLatency = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_A;

	/* Color LCD configuration ------------------------------------
	 LCD configured as follow:
	    - Data/Address MUX = Disable
	    - Memory Type = SRAM
	    - Data Width = 16bit
	    - Write Operation = Enable
	    - Extended Mode = Enable
	    - Asynchronous Wait = Disable */
	FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
	FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
	FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
	FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
	FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
	FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
	FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;
	FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;

	FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);

	/* - BANK 4 (of NOR/SRAM Bank 0~3) is enabled */
	FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE);
}


void fpga_fsmc_init_old(void)
{
//	FPGA_CtrlLinesConfig( );
//	FPGA_FSMCConfig( );
	printf("fpga_fsmc_init over!\n");
}












 

#if 0

void select_which_cha_old(unsigned short cha)
{
		fpga_write(0,cha);//ѡ�������Ӧ��ͨ��
}

void delay_fpga_old(unsigned char dly_cnt)
{
	unsigned int i;
	for(;dly_cnt>0;dly_cnt--)
	{
		for(i=50000;i>0;i--);
	}
}

unsigned short check_chax_breadout_v_flag_old(unsigned char cha)
{
	unsigned short reg_read_from_fpga;
	cha %= 10;
	fpga_write(0,cha);
	reg_read_from_fpga = fpga_read(1);
	if( reg_read_from_fpga&(1<<1) )
	{
		return 1;
	}
	else
	{
		return 0;
	}
		
}

void clear_chax_breakout_flag(unsigned char cha)
{
	fpga_write(0,(1<<(cha+4)) );	
}


void set_chax_thr(unsigned short cha,unsigned short thr)
{
	select_which_cha( cha );
	fpga_write(1,thr);	
}



void fsmc_fpga_test_main_old()
{
		unsigned int i,m;
		unsigned short run_reg;
		unsigned short chax_sta_reg;
		short chax_dat;
		unsigned short pre_chax_dat;
		unsigned short buf[256];
		unsigned char first;
		unsigned int chax_dat_len;
	
		fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ
	

		run_reg = 0x3ff0;
		start_run_old(run_reg);//����10·ͬʱ�ɼ�


		for(i=0;i<10;i++)
		{
			do
			{
				//�ɼ��볬ʱ�ȴ�����
				chax_sta_reg = check_sample_dat_over(i);
			}while((chax_sta_reg&1)==0);//�ȴ���ͨ��(ͨ��0~9�е�һ��)�ɼ����
			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			first = 1;
			do
			{
				if(chax_dat_len>=256)
				{
					read_channel_data(i,256,buf,first);//���FPGA�е����ݶ���256����ÿ�ζ�256��16bit��?
					chax_dat_len-= 256;
				}
				else
				{
					read_channel_data(i,chax_dat_len,buf,first);
				}
				first = 0;
				
			}while(chax_dat_len);					
		}
}


void find_which_cha_breadout()
{
		unsigned int i,m;
		unsigned short run_reg;
		unsigned short chax_sta_reg;
		short chax_dat;
		unsigned short pre_chax_dat;
		unsigned short buf[256];
		unsigned char first;
		unsigned int chax_dat_len;
		unsigned short thr=0x140;
	
		fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ
	
	
		re_check:
	
		for(i=0;i<4;i++)
		{
			set_chax_thr(i,thr);
		}


		for(i=0;i<4;i++)
		{
			chax_sta_reg = check_chax_breadout_v_flag(i);
			if(chax_sta_reg)
			{
				printf("cha=%d,chax_sta_reg=%d\r\n",i,chax_sta_reg);
				chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
				chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
				clear_chax_breakout_flag(i);
				first = 1;
				do
				{
					if(chax_dat_len>=256)
					{
						read_channel_data(i,256,buf,first);//���FPGA�е����ݶ���256����ÿ�ζ�256��16bit��?
						chax_dat_len-= 256;
					}
					else
					{
						read_channel_data(i,chax_dat_len,buf,first);
						chax_dat_len = 0;
					}
					first = 0;
					
				}while(chax_dat_len);
				
			}					
		}
		goto re_check;
}

#endif

//run_chabit4~ bit13Ϊ1�ֱ�����ɼ�0~9·ͨ������ʼ�ɼ�
void start_run(volatile unsigned short run_cha)
{
 	
   	fpga_write(0, run_cha);
}

//return 1 �Ѳɼ����   0:���ڲɼ�
unsigned short check_sample_dat_over(volatile unsigned char channel)
{
   volatile unsigned short dat;


   fpga_write(0, channel);//ѡ���Ӧ��ͨ��
   dat = fpga_read(1);//��ȡ��Ӧͬʱ�Ƿ�ɼ����

   if (dat & (1 << 0)) {
      return 1;
   }
   else {
      return 0;
   }
}

unsigned int read_channel_dat_len(volatile unsigned char channel)
{
   unsigned int dat_len;
   unsigned short tmp_h;
   unsigned short tmp_l;


   fpga_write(0, channel);

   tmp_h = fpga_read(2);
   tmp_l = fpga_read(3);

   dat_len = (tmp_h << 16) + tmp_l;

   return (dat_len<<1);//���ص����ݳ�����u8�ĳ���*/
	/*	if(channel<4)
		{
				return 20000;
		}
		else 
		{
				return 20480;
		}*/
}
unsigned int cnt=0;
unsigned int index=0;
unsigned int read_channel_data(unsigned char channel, unsigned int dat_len, unsigned short *buf, unsigned char first)
{
	unsigned int i,n;
	volatile unsigned short *p;
	short dat;
	volatile unsigned short m;


	p = (volatile unsigned short *)buf;

	dat_len >>= 1;
	if(first)
	{
		fpga_write(0, (1<<14)|channel);
		m = fpga_read(7);
		index = 0;
		cnt = 0;
		cha2_read_dat_cnt_global = 0;
	}
	for(i=0;i<dat_len;i++)
	{
		*p = fpga_read(7);
		dat = *p;
	/*	if( (first)&&(i<10)  )
		{
			if(channel<4)
				printf("cha=%d dat%d=%d\r\n",channel,i,dat);
			else
				printf("cha=%d dat%d=%d\r\n",channel,i,(short)dat);
		}*/
		//if((channel==4)||(channel==5)||(channel==6)||(channel==7)||(channel==8)||(channel==9))
		//if((channel==4)&&(cha2_read_dat_cnt_global<32))
		if( (channel==channel_display_select)&&(cha2_read_dat_cnt_global<1024))
		{
			cha2_read_dat_cnt_global++;
			if(cha2_read_dat_cnt_global<1024)
			{
	//			printf("%d,%d,%d\r\n",channel,cha2_read_dat_cnt_global,dat);
			}
		}
		
		
	//	if(((cnt%8)==0)&&(channel==4)&&(first)&&(i==0))
		//if( (channel<4)&&(index<100) )
		{
			/*	if( ((channel==0)&&(dat!=0x123))||
						((channel==1)&&(dat!=0x234))||
						((channel==2)&&(dat!=0x345))||
						((channel==3)&&(dat!=0x456))||
						((channel==4)&&(dat!=0x567))||
						((channel==5)&&(dat!=0x678))||
						((channel==6)&&(dat!=0x789))||
						((channel==7)&&(dat!=0x89a))||
						((channel==8)&&(dat!=0x9ab))||
						((channel==9)&&(dat!=0xabc)) )
				{
					printf("error cha:%d,index:%d,dat: %x\n",channel,index,dat);
				}*/
				//	delay(1);
		//	printf("%d,%d\n",cnt,(short)dat);
			index++;
		}
		cnt++;
		p++;
		
	}
}





/*******************************************************************************
*	������: FPGA_CtrlLinesConfig
*	��  ��: ��
*	��  ��: ��
*	��  ��: ����FPGA���ƿ��ߣ�FSMC�ܽ�����Ϊ���ù���
*/
static void FPGA_CtrlLinesConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* ʹ�� FSMC, GPIOD, GPIOE, GPIOF, GPIOG �� AFIO ʱ�� */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE |
	                     RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG |
	                     RCC_APB2Periph_AFIO, ENABLE);

	/* ���� PD.00(D2), PD.01(D3), PD.04(NOE), PD.05(NWE), PD.08(D13), PD.09(D14),
	 PD.10(D15), PD.14(D0), PD.15(D1) Ϊ����������� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5 |
	                            GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_14 |
	                            GPIO_Pin_15; // | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	/* ���� PE.07(D4), PE.08(D5), PE.09(D6), PE.10(D7), PE.11(D8), PE.12(D9), PE.13(D10),
	 PE.14(D11), PE.15(D12) Ϊ����������� */
	/* PE3,PE4 ����A19, A20, STM32F103ZE-EK(REV 2.0)����ʹ�� */
	/* PE5,PE6 ����A21, A22, STM32F103ZE-EK(REV 1.0)����ʹ�� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
	                            GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 |
	                            GPIO_Pin_15 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	/* ���� PD11(A16)  PD12(A17)  PD13(A18))  Ϊ����������� */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13;
	//GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_12;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	/* ���� PD.7(NE1 ) Ϊ�����������  */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}

/*******************************************************************************
*	������: FPGA_FSMCConfig
*	��  ��: ��
*	��  ��: ��
*	��  ��: ����FSMC���ڷ���ʱ��
*/
static void FPGA_FSMCConfig(void)
{
	FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
	FSMC_NORSRAMTimingInitTypeDef  FSMC_NORSRAMTimingInitStructure;

	/*-- FSMC Configuration ------------------------------------------------------*/
	/*----------------------- SRAM Bank 1 ----------------------------------------*/
	/* FSMC_Bank1_NORSRAM1 configuration */
	FSMC_NORSRAMTimingInitStructure.FSMC_AddressSetupTime = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_AddressHoldTime = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_DataSetupTime = 14;	   //xiewei
	FSMC_NORSRAMTimingInitStructure.FSMC_BusTurnAroundDuration = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_CLKDivision = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_DataLatency = 0;
	FSMC_NORSRAMTimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_A;

	/* Color LCD configuration ------------------------------------
	 LCD configured as follow:
	    - Data/Address MUX = Disable
	    - Memory Type = SRAM
	    - Data Width = 16bit
	    - Write Operation = Enable
	    - Extended Mode = Enable
	    - Asynchronous Wait = Disable */
	FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM1;
	FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable;
	FSMC_NORSRAMInitStructure.FSMC_MemoryType = FSMC_MemoryType_SRAM;
	FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;
	FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode = FSMC_BurstAccessMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
	FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;
	FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
	FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Disable;
	FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable;
	FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;
	FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &FSMC_NORSRAMTimingInitStructure;

	FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure);

	/* - BANK 4 (of NOR/SRAM Bank 0~3) is enabled */
	FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE);
}


void fpga_fsmc_init(void)
{
	FPGA_CtrlLinesConfig( );
	FPGA_FSMCConfig( );
	printf("fpga_fsmc_init over!\n");
}






void select_which_cha(unsigned char cha)
{
		fpga_write(0,cha);//ѡ�������Ӧ��ͨ��
}

void delay_fpga(unsigned char dly_cnt)
{
	unsigned int i;
	for(;dly_cnt>0;dly_cnt--)
	{
		for(i=50000;i>0;i--);
	}
}


void read_chax_dat(volatile unsigned char cha)
{
		volatile unsigned int i,m;
		volatile unsigned short run_reg;
		volatile unsigned short chax_sta_reg;
		volatile short chax_dat;
		unsigned short pre_chax_dat;
		unsigned short buf[256];
		unsigned char first;
		unsigned int chax_dat_len;
		start_run(0x10<<cha);
	
		GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)0);//pd6������������
		delay(10);
		GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)1);//pd6������������
	
		i=cha;
		{
			do
			{
				//�ɼ��볬ʱ�ȴ�����
				chax_sta_reg = check_sample_dat_over(i);
			}while((chax_sta_reg&1)==0);//�ȴ���ͨ��(ͨ��0~9�е�һ��)�ɼ����
			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			first = 1;
			do
			{
				if(chax_dat_len>=256)
				{
					read_channel_data(i,256,buf,first);//���FPGA�е����ݶ���256����ÿ�ζ�256��16bit��?
					chax_dat_len-= 256;
				}
				else
				{
					read_channel_data(i,chax_dat_len,buf,first);
					chax_dat_len = 0;
				}
				first = 0;
				
			}while(chax_dat_len);					
		}
	
}
unsigned int check_num=0;
void test_fsmc_read()
{
		unsigned int n;
		unsigned short dat;
		unsigned short dat_pre;
	
			for(n=0;n<1024;n++)
			{
				dat_pre = dat;
				dat = fpga_read(7)&0xfff;
			
				if (  ((dat-dat_pre)!=1)&&(n>0)&&(dat_pre!=0xfff) )
				{
					printf("error dat=%x dat_pre=%x n=%d\r\n",dat,dat_pre,n);
				}
			}
			check_num++;
		//	printf("check %d over\r\n",check_num);
			
}
void delay_sram(unsigned int i)
{
	unsigned char m;
	for(;i>0;i--)
		for(m=0;m<20;m++);
}
unsigned char debug_flag=1;
unsigned short cha10_thr=0x100;
unsigned short cha10_change_rate=0x100;
void test_dw_main()
{
	unsigned char i;
	unsigned int n;
	unsigned short chax_sta_reg;
	unsigned int chax_dat_len;
	static unsigned short dat;
	static unsigned short dat_pre;
	unsigned int time_cnt;
	unsigned char int_flag;
	

	fpga_write(7,0x1c00);
	recheck:
	int_flag = 0;
	
	GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)0);//pd6������������

	GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)1);//pd6������������
	
	for(i=10;i<=12;i++)
	{
		fpga_write(0,10);
		fpga_write(1,cha10_thr);
		fpga_write(6,cha10_change_rate);
		chax_sta_reg = check_sample_dat_over(i);
		if( chax_sta_reg )
		{
			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���

			int_flag = 1;
			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			fpga_write(0, (1<<14)|i );
			time_cnt = (fpga_read(8)<<16)+fpga_read(9);
//			for(n=0;n<6;n++)
			////////goto print;
				fpga_read(7);
			if(debug_flag==1)
			{
		//		chax_dat_len = 800;
			}
			for(n=0;n<chax_dat_len;n++)
			{
				dat_pre = dat;
				dat = fpga_read(7)&0xfff;		
				delay_sram(1);

				write_sram( dat,n);
				#if 0
				dat = read_sram(n);
				if (  ((i==10)&&((dat-dat_pre)!=1)&&(n>0))||
							((i==11)&&((dat-dat_pre)!=2)&&(n>0))||
							((i==12)&&((dat-dat_pre)!=3)&&(n>0)) )
				{
					printf("error channel %d n=%d dat=%x dat_pre=%x\r\n",i,n,dat,dat_pre);
				}
				#endif
			}
			for(n=0;n<chax_dat_len;n++)
			{
			//	FSMC_SRAM_ReadBuffer(&dat,n,1);	
				
			}
			print:
			printf("channel %d have dat dat_len=%d time_cnt=%x\r\n",i,chax_dat_len,time_cnt);
	//		fpga_write(7,1<<i);
		}
	}
	if(int_flag ==1)
	{
		fpga_write(7,0x1c00);
		delay_sram(1);
		fpga_write(7,0x1c00);
	}
	goto recheck;
}

short cha4_dat_buf[1024];
float cha4_dat_float_buf[1024];
void read_current()
{
		unsigned int i,m;
		unsigned short run_reg;
		unsigned short chax_sta_reg;
		short chax_dat;
		unsigned short pre_chax_dat;
		unsigned char first;
		unsigned int chax_dat_len;
	unsigned char send_one_second_clk_flag;
	float current;
	
		fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ


		run_reg = 0x3ff0;
		start_run(run_reg);//����10·ͬʱ�ɼ�
		send_one_second_clk_flag = 1;
		if(send_one_second_clk_flag)
		{
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)0);//pd6������������
	//	delay(10);
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)1);//pd6������������
		}


		for(i=0;i<10;i++)
		{
			do
			{
				//�ɼ��볬ʱ�ȴ�����
				chax_sta_reg = check_sample_dat_over(i);
			}while((chax_sta_reg&1)==0);//�ȴ���ͨ��(ͨ��0~9�е�һ��)�ɼ����
			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			printf("chax_dat_len=%d\r\n",chax_dat_len);
			first = 1;
			do
			{
				if(chax_dat_len>=2048)
				{
					read_channel_data(i,2048,cha4_dat_buf,first);//���FPGA�е����ݶ���1024����ÿ�ζ�1024��16bit��?
					chax_dat_len-= 2048;
					
					if( (i>=4)&&(i<=9)&&(first) )
					{
						calc_abc(cha4_dat_float_buf,(unsigned short*)cha4_dat_buf, 2048,i);

		
						calc_pf_current_abc(&current,cha4_dat_float_buf,2048);
						printf("cha%d current =%f\r\n",i,current);
					}
				}
				else
				{
					read_channel_data(i,chax_dat_len,cha4_dat_buf,first);
					chax_dat_len = 0;
				}
				first = 0;
				
			}while(chax_dat_len);					
		}
}

#if 1  /*10·��������*/

void fsmc_fpga_test_main()
{
		unsigned int i,m;
		unsigned short run_reg;
		unsigned short chax_sta_reg;
		short chax_dat;
		unsigned short pre_chax_dat;
		unsigned short buf[256];
		unsigned char first;
		unsigned int chax_dat_len;
	unsigned char send_one_second_clk_flag;
	
		fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ


		run_reg = 0x3ff0;
		start_run(run_reg);//����10·ͬʱ�ɼ�
		send_one_second_clk_flag = 1;
		if(send_one_second_clk_flag)
		{
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)0);//pd6������������
	//	delay(10);
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)1);//pd6������������
		}


		for(i=0;i<10;i++)
		{
			do
			{
				//�ɼ��볬ʱ�ȴ�����
				chax_sta_reg = check_sample_dat_over(i);
			}while((chax_sta_reg&1)==0);//�ȴ���ͨ��(ͨ��0~9�е�һ��)�ɼ����
			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			printf("chax_dat_len=%d\r\n",chax_dat_len);
			first = 1;
			do
			{
				if(chax_dat_len>=256)
				{
					read_channel_data(i,256,buf,first);//���FPGA�е����ݶ���1024����ÿ�ζ�1024��16bit��?
					chax_dat_len-= 256;
				}
				else
				{
					read_channel_data(i,chax_dat_len,buf,first);
					chax_dat_len = 0;
				}
				first = 0;
				
			}while(chax_dat_len);					
		}
}
#else  /*һ�βɼ�һ·��ѭ��ʮ�β���*/
void fsmc_fpga_test_main()
{
	unsigned char i;
	
	fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ
	fpga_write(0,1);
	fpga_read(0);
	re_test:
	for(i=0;i<10;i++)
	{
		read_chax_dat(i);
		printf("check cha%d over!\n",i);
	}
	goto re_test;
}
#endif



void find_which_cha_breadout()
{
	unsigned char i,m;
	volatile unsigned short ret;
	for(i=0;i<4;i++)
	{
		fpga_write(0,((1<<14)|i));
	//	fpga_write(1,1);
		ret = fpga_read(1);
		if(ret&2)
		{
			for(m=0;m<16;m++)
			{
			//	fpga_write(0,((1<<14)|i));
				ret = fpga_read(7);
				if(m>0)
				{
					printf("cha=%d dat=%x\r\n",i,ret);
				}
			}
			fpga_write(0,1<<(i+4));//���־
		}
		
	}
	
}




void test_fpga_fsmc_dat_from_ad_module()
{
		unsigned int i,m;
		unsigned short run_reg;
		unsigned short chax_sta_reg;
		short chax_dat;
		unsigned short pre_chax_dat;
		unsigned short debug_fsmc[1024];
		unsigned int err;
		unsigned int chax_dat_len;
		unsigned char send_one_second_clk_flag;

	//fpga_fsmc_init();//��ʼ������fpgaҪ�õ��ĵ�Ƭ����Դ

		run_reg = 0x3ff0;
		start_run(run_reg);//����10·ͬʱ�ɼ�
		send_one_second_clk_flag = 1;
		if(send_one_second_clk_flag)
		{
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)0);//pd6������������
	//	delay(10);
			GPIO_WriteBit(GPIOD,  GPIO_Pin_6, (BitAction)1);//pd6������������
			fpga_write(8,1);
		}


		for(i=0;i<10;i++)
		{
			do
			{
				//�ɼ��볬ʱ�ȴ�����
				chax_sta_reg = check_sample_dat_over(i);
			}while((chax_sta_reg&1)==0);//�ȴ���ͨ��(ͨ��0~9�е�һ��)�ɼ����
//			chax_dat_len = read_channel_dat_len(i);//��ȡ��ͨ�������ݳ���
//			chax_dat_len /= 2;//��������ݳ��ȱ����byte���ȣ���ÿ�δ�fpga���Ƕ�һ��16bit�޷�����
			chax_dat_len = 2000;
			//printf("chax_dat_len=%d\r\n",chax_dat_len);
			if((i==0)&&(chax_dat_len>=1024))
			{
				for(i=0;i<1024;i++)
				{
					debug_fsmc[i]= fpga_read(12);
				}
				for(i=0;i<1023;i++)
				{
					if( (debug_fsmc[i+1]-debug_fsmc[i])!=1 )
					{
						err++;
						printf("error debug_fsmc[i+1]=%d debug_fsmc[i]=%d\r\n",debug_fsmc[i+1],debug_fsmc[i]);
					}
				}
				if(err)
				{
					printf("test fpga fsmc err cnt = %d  \r\n",err);
				}
				else
				{
					printf(" test fpga ok\r\n");
				}
			
		}
	}
}


