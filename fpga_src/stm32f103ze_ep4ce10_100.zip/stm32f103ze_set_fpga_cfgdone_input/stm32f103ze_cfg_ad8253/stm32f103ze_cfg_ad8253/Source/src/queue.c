#include "queue.h"
#include "delay.h"

void init_queue(struct Queue* pQueue)
{
	pQueue->rear=pQueue->front=0;
}

int  get_queue_len(struct Queue* pQueue)
{
	int ret;
	ret = (pQueue->rear - pQueue->front + MAX_QUEUE_LEN) % MAX_QUEUE_LEN;
	return ret;
}

int add_queue(struct Queue* pQueue,unsigned char em)
{
	if((pQueue->rear+1)%MAX_QUEUE_LEN == pQueue->front){
		pQueue->front = (pQueue->front+1)%MAX_QUEUE_LEN;//������ʱ����ͷ
	}
	
	pQueue->rear = (pQueue->rear+1)%MAX_QUEUE_LEN;
	pQueue->queue_buf[pQueue->rear] = em;

	return 1;
}

int del_queue(struct Queue* pQueue,unsigned char *q)
{
	int ret = 0;
	if(pQueue->front == pQueue->rear){
       ret = 0;
	}
    else{ 
		pQueue->front=(pQueue->front+1)%MAX_QUEUE_LEN;
		*q=pQueue->queue_buf[pQueue->front];
		ret = 1;
    }
	return ret;
}

/* �Ӷ��ж�ȡһ������ */
char read_queue_timeout(struct Queue* pQueue,unsigned char* buf,unsigned char len,unsigned int timeout)
{    
    int i = 0, t = 0;
	while( t < timeout){	    		 
		if(get_queue_len(pQueue)>=len){
			for(i=0;i<len;i++){
			   if(del_queue(pQueue,buf)){
			   		return -1;			   		 
			   }
			   buf++;
			}
		    return 1;
	    }
	    else{  
		   delay_ms(1);
		   t++;
		   continue;
	    }
		delay_ms(1);
		t++;
	}

	return 0;
}