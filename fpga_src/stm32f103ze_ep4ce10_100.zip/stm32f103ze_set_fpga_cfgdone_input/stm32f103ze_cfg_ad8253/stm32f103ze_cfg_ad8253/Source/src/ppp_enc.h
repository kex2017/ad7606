#ifndef __PPP_ENC_H__
#define __PPP_ENC_H__

#ifndef PPP_ENC_DEC_BUF_LEN
#define PPP_ENC_DEC_BUF_LEN 64 /* the internal buffer size for encoding or decoding*/
#endif

#ifndef BUF_LEN
#define BUF_LEN 64 /* the internal buffer size for encoding or decoding*/
#endif

#define PPP_FRAME_FLAG  0x7e /*The frame begin or the end character*/
/*Given buf length shall be no more than (PPP_ENC_DEC_BUF_LEN >> 1) - 2)*/

typedef signed char (*READ_API)(unsigned char* buf,int len);
typedef void (*WRITE_API)(unsigned char* buf,int len);

int pppEncode(unsigned char * buf, int len);

/*Given buf length shall be no more than PPP_ENC_DEC_BUF_LEN*/
int pppDecode(unsigned char * buf, int len);


int read_hdlc(unsigned char * buf,int len,READ_API fun_read);
int send_hdlc(unsigned char * buf, int len,WRITE_API fun_write);
#endif

