#ifndef __QUEUE_H__
#define __QUEUE_H__

#define MAX_QUEUE_LEN   256

struct Queue{
  volatile unsigned char queue_buf[MAX_QUEUE_LEN];
  volatile int  front;
  volatile int  rear;
};

void init_queue(struct Queue* pQueue);
int  get_queue_len(struct Queue* pQueue);
int  add_queue(struct Queue* pQueue,unsigned char em);
int  del_queue(struct Queue* pQueue,unsigned char *q);
char read_queue_timeout(struct Queue* pQueue,unsigned char* buf,unsigned char len,unsigned int timeout);


#endif	  /* __QUEUE_H__ */
