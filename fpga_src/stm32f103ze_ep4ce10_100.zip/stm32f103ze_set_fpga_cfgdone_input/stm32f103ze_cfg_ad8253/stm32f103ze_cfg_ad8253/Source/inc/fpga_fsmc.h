//-----------------define-------------------------------//
#ifndef __fpga_fsmc_h__
#define __fpga_fsmc_h__

//-----------------Include files-------------------------//

//----------------- Define ------------------------------//
#define   FPGA_BASE_ADDR			0x60000000
#define AD_10M_BPS 0x40
#define SYNC_INMODE (1<<13)
#define fpga_write(offset, data) *((volatile unsigned short int*)(FPGA_BASE_ADDR + (offset << 17))) = data

#define fpga_read(offset)       *((volatile unsigned short int*)(FPGA_BASE_ADDR + (offset << 17)))

//----------------- Typedef -----------------------------//
void test_dw_main();
void fpga_fsmc_init(void);
void test_fpga(void);
void read_ad_max_and_aver();
void test_fpga_ad_dat2();
//---------------- Extern -------------------------------//
 void test_fpga_for_gis_cgq();
		  void start_fpga_sample();

void check_write_over();

//void init_fpga_write_dat_to_sdram();
void init_fpga_write_dat_to_sdram(unsigned short *dat_begin,unsigned short *dat_add);
void read_fpga_sdram_dat_by_fsmc();
void check_sdram_dat_ok(unsigned short cha,unsigned short dat_begin,unsigned short dat_add);

#define READ_DAT_MODE 1	 //0:��ʾ���Ĵ���ģʽ���ӼĴ�����ȡ����ֵ����ֵ   1����ʾ��(����+��λ+�ŵ����)��������ȡ����ֵ
#endif //__fpga_fsmc_h__